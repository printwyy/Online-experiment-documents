package except;
import java.util.Scanner;
import java.io.*;
public class circle {
	public static void main(String[] args) throws IOException
	{
		BufferedReader b=new BufferedReader(new InputStreamReader(System.in));
		new InputStreamReader(System.in);
		try {
			System.out.println("圆的面积为"+Area(Double.parseDouble(b.readLine())));
			
		}catch(NumberFormatException e){
			System.out.println("非法输入");
		}
	}
	public static double Area(double r){
		return Math.PI*r*r;
	}
}
