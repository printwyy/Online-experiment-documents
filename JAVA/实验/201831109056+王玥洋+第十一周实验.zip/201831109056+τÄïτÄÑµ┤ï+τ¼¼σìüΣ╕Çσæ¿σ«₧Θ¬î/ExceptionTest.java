package except;
public class ExceptionTest{
	public static void main(String[] args)
	{
			for(int i=0; i<4; i++) { 
				int a;
				try {
					switch(i) {
					case 0:
						int zero=0;
						// 除数为 0
						a = 4 / zero;
						break;
					case 1: // 数组越界访问
						int[] b = new int[5]; a = b[5];
						break;
					case 2:
						int[] c = new int[-1];
						a = c[0];
						break; 
					case 3:
						int[] d = null; 
						a = d[0]; 
						break;
					}
				}
		catch(Exception e) {
			System.out.println("Case " + i + " has an exception");
			System.out.println(e); 
			}
		}
	
}
}
