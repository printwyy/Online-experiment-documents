package except;
import java.lang.String.*;
import java.util.*;
public class student {
	public static void main(String[] args)
	{
		students a=new students();
		String name,address;
		Scanner in = new Scanner(System.in);
		try {
			name=in.nextLine();
			if(name.length()<1||name.length()>5) {
				throw new IllegaNameException("非法姓名异常");
			}
			a.name=name;
			address=in.nextLine();
			if(!address.contains("市")||!address.contains("省")) {
				throw new IllegalAddressException("非法地址异常");
			}
		}catch(IllegalAddressException e) {
			e.printStackTrace();
		}
		catch(IllegaNameException e1) {
			e1.printStackTrace();
		}
	}
}
class students{
	String name;
	String address;
	public students() {}
	public students(String n,String add) {
		name=n;
		address=add;
	}
	public void setname(String n) {
		name=n;
	}
	public void setaddress(String add) {
		address=add;
	}
}
class IllegaNameException extends Exception{
	public IllegaNameException() {
		
	}
	public IllegaNameException(String s) {
		super(s);
	}
}
class IllegalAddressException extends Exception{
	public IllegalAddressException() {
		
	}
	public IllegalAddressException(String s) {
		super(s);
	}
}
