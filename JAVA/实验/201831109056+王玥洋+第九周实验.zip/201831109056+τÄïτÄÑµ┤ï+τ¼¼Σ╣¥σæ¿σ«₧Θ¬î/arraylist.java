package hello;
import java.util.Collections;
import java.lang.reflect.Array;
import java.util.Comparator;
import java.util.ArrayList;
import java.util.Iterator;
public class arraylist {
	public static void main(String[] args) {
		ArrayList<String> l=new ArrayList<String>();
		ArrayList<String> a=new ArrayList<String>();;
		l.add("1");
		l.add("6");
		l.add("2");
		l.add("4");
		System.out.println(l.isEmpty());
		for(Object o:l) {
			System.out.println(o);
		}
		int len=l.size();
		System.out.println("-------------");
		for(int i=0;i<len;i++) {
			System.out.println(l.get(i));
		}
		a.addAll(0,l);
		l.clear();
		System.out.println(l.isEmpty());
		System.out.println(a.isEmpty());
		Collections.sort(a);
		System.out.println("-------------");
		for (Iterator<String> it =a.iterator(); it.hasNext();) {
			            System.out.println(it.next());
		}
		System.out.println("-------------");
		System.out.println(a.indexOf("6"));
		a.remove(a.indexOf("6"));
		System.out.println(a.contains("6"));
	}
}
