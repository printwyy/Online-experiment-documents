package hello;
import java.util.Collections;
import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Arrays;
public class map {
	public static void main(String[] args) {
		Map<String, Integer> a=new <String, Integer>HashMap();
		Map b=new HashMap();
		a.put("text",1234);
		a.put("map",564);
		a.put("ye",34);
		a.put("he",11);
		a.put("text",123);
		System.out.println(a.isEmpty());
		System.out.println(b.isEmpty());
		System.out.println("-------------");
		Set<String> set = a.keySet();
		for(String s:set) {
			System.out.println(s+"="+a.get(s));
		}
		System.out.println("-------------");
		a.remove("text");
		Iterator it=a.keySet().iterator();
		Object key;
		Object value;
		while(it.hasNext()){
			key=it.next();
			value=a.get(key);
			System.out.println(key+":"+value);
		}
		System.out.println("-------------");
		Iterator<Map.Entry<String, Integer>> c = a.entrySet().iterator();
		  while (c.hasNext()) {
		   Map.Entry<String, Integer> entry = c.next();
		   System.out.println("key= " + entry.getKey() + " and value= " + entry.getValue());
		}
		System.out.println("-------------");
		System.out.println(a.containsKey("text"));
		System.out.println(a.containsValue(11));
	}
}
