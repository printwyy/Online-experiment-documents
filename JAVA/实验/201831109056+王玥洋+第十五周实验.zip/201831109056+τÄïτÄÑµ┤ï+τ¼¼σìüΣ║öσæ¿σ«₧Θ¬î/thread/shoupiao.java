package thread;

public class shoupiao {
	public static void main(String[] args) {
		kou t =new kou();
		for(int i=1;i<6;i++) {
			new Thread(t,"Thread"+i).start();
		}
	}
}

class kou implements Runnable{
	private volatile int ticket=100;
	String str =new String("");
	public void run() {
			while(ticket>0) {
				synchronized(str) {
					if(ticket>=0) {
						System.out.println(Thread.currentThread().getName()+""+"剩余："+ticket);
						ticket--;
					}
				}
			}
		
	}
}