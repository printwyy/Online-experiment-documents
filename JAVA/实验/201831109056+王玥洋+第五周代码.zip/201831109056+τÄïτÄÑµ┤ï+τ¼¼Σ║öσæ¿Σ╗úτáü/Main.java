package hello;

import java.util.Scanner;

public class Main {
     public  static  void  main(String[]  args) {
        Scanner  in  =  new  Scanner(System.in);
        Fraction  a  =  new  Fraction(in.nextInt(),  in.nextInt());
        Fraction  b  =  new  Fraction(in.nextInt(),in.nextInt());
        a.print();
        b.print();
        a.plus(b).print();
        a.multiply(b).plus(new  Fraction(5,6)).print();
        a.print();
        b.print();
        in.close();
} }
class Fraction {
	int a;
	int b;
	public Fraction(int i,int j) {
		a=i;
		b=j;
	}
	 void print() {
	        int x = a,y = b,r;
	        if(a == b) {
	            System.out.println(1);
	            return;
	        }
	        while(y!=0) {
	            r = x%y;
	            x=y;
	            y=r;
	        }
	        a/=x;
	        b/=x;
	        System.out.println(a + "/" + b);
	    }
	    double toDouble() {
	        return a/b;
	    }
	    Fraction plus(Fraction r) {
	        Fraction result = new Fraction(0,0);
	        result.b=this.b*r.b;
	        result.a=this.a*r.b+r.a*this.b;
	        return result;
	    }
	    Fraction multiply(Fraction r) {
	        Fraction result=new Fraction(0,0);
	        result.a=this.a*r.a;
	        result.b=this.b*r.b;
	        return result;
	    }

}
