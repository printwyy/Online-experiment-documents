package hello;

public class Stu {
	public  static  void  main(String[]  args) {
		Student a,b;
		a=new Student();
		b=new Student("tom",'m',15,'回',"changsha",150);
		a.print();
		b.print();
	}
}
class Student{
	String name;
	char sex;
	int age;
	char minzu;
	String jiguan;
	int score;
	Student(){
		this.name="wu";
		this.sex='w';
		this.age=1;
		this.minzu='汉';
		this.jiguan="bejing";
		this.score=0;
	}
	Student(String name,char sex,int age,char minzu,String jiguan,int score){
		this.name=name;
		this.sex=sex;
		this.age=age;
		this.minzu=minzu;
		this.jiguan=jiguan;
		this.score=score;
	}
	public void print() {
		System.out.println(name);
		System.out.println(sex);
		System.out.println(age);
		System.out.println(minzu);
		System.out.println(jiguan);
		System.out.println(score);
	}
	
}
