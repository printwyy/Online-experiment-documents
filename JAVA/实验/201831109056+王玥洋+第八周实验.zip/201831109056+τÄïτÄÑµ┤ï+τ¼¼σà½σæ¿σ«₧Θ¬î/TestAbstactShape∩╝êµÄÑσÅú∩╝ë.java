
import java.util.Random;
interface Shape{	
	abstract double getPerimeter();
	abstract double getArea();
}
class Rectangle implements Shape{
	double width;
	double height;
	Rectangle(double w,double h){
		this.height=h;
		this.width=w;
	}
	public double getPerimeter() {
		return (this.width+this.height)*2;
	}
	public double getArea() {
		return this.width*this.height;
	}
	double getwidth() {
		return this.width;
	}
	double getheight() {
		return this.height;
	}
	void setwidth(double w) {
		this.width=w;
	}
	void setheight(double h) {
		this.height=h;
	}
	public String toString() {
		String ans;
		ans="Rectangle[width="+this.width+",height="+this.height+"]";
		return ans;
	}
}
class Circle implements Shape {
	double radius;
	int originX;
	int originY;
	Circle(double r,int x,int y){
		this.originX=x;
		this.radius=r;
		this.originY=y;
	}
	public double getPerimeter() {
		return Math.PI*(this.radius*2);
	}
	public double getArea() {
		return Math.PI*this.radius*this.radius;
	}
	double getradius() {
		return this.radius;
	}
	int getoriginx() {
		return this.originX;
	}
	int getoriginy() {
		return this.originY;
	}
	void setradius(double r) {
		this.radius=r;
	}
	void setoringinx(int x) {
		this.originX=x;
	}
	void setoriginy(int y) {
		this.originY=y;
	}
	public String toString() {
		String ans;
		ans="Circle [radius="+this.radius+",originX="+this.originX+",originY="+this.originY+"]";
		return ans;
	}
}
class Triangle implements Shape{
	double sideA;
	double sideB;
	double sideC;
	Triangle(double a,double b,double sc){
		this.sideA=a;
		this.sideB=b;
		this.sideC=sc;
		if(a+b<=sc||a+sc<=b||b+sc<=a)
			System.out.println("不是有效的边长");
	}
	public double getPerimeter() {
		return this.sideA+this.sideB+this.sideC;
	}
	public double getArea() {
		double p=this.getPerimeter()/2;
		double s;
		if(p*(p-this.sideA)*(p-this.sideB)*(p-this.sideC)<0)
			return 0;
		s=Math.sqrt(p*(p-this.sideA)*(p-this.sideB)*(p-this.sideC));
		return s;
	}
	public String toString() {
		return "Triangle[sideA="+this.sideA+",sideB="+this.sideB+",sideC="+this.sideC+"]";
	}
}
public class TestAbstactShape {
	public static void main(String[] args) {
		Object t[]=new Object[100];
		Random rm=new Random();
		int ran,x,y;
		double r,a,b,c,w,h,area=0.0,p=0.0;
		for(int i=0;i<100;i++) {
			ran=rm.nextInt(3);
			x=rm.nextInt(10);
			y=rm.nextInt(10);
			r=rm.nextInt(10);
			a=rm.nextInt(10);
			b=rm.nextInt(10);
			c=rm.nextInt(10);
			w=rm.nextInt(10);
			h=rm.nextInt(10);
			switch (ran) {
				case 0:
					Circle cir=new Circle(r,x,y);
					t[i]=cir;
					area+=((Shape)t[i]).getArea();
					p+=((Shape)t[i]).getPerimeter();
					System.out.println(t[i].toString());				
					break;
				case 1:
					t[i]=new Triangle(a,b,c);
					area+=((Shape)t[i]).getArea();
					p+=((Shape)t[i]).getPerimeter();
					System.out.println(t[i].toString());
					break;
				case 2:
					t[i]=new Rectangle(w,h);
					area+=((Shape)t[i]).getArea();
					p+=((Shape)t[i]).getPerimeter();
					System.out.println(t[i].toString());
					break;
			}
		}
		System.out.println("总面积："+area);
		System.out.println("总周长："+p);
	}
}
