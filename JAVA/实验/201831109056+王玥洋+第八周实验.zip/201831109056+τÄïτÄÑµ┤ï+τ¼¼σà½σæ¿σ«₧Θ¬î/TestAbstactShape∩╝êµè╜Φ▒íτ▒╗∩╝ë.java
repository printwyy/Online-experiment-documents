
import java.util.*;
abstract class Shape{
	String color;
	abstract double getPerimeter();
	abstract double getArea();
	Shape(){}
	Shape(String c){
		this.color=c;
	}
	String getcolor() {
		return this.color;
	}
	void setcolor(String c) {
		this.color=c;
	}
}
class Rectangle extends Shape{
	double width;
	double height;
	Rectangle(String c,double w,double h){
		super(c);
		this.height=h;
		this.width=w;
	}
	double getPerimeter() {
		return (this.width+this.height)*2;
	}
	double getArea() {
		return this.width*this.height;
	}
	double getwidth() {
		return this.width;
	}
	double getheight() {
		return this.height;
	}
	void setwidth(double w) {
		this.width=w;
	}
	void setheight(double h) {
		this.height=h;
	}
	public String toString() {
		String ans;
		ans="Rectangle[color="+this.color+",width="+this.width+",height="+this.height+"]";
		return ans;
	}
}
class Circle extends Shape {
	double radius;
	int originX;
	int originY;
	Circle(String c,double r,int x,int y){
		super(c);
		this.originX=x;
		this.radius=r;
		this.originY=y;
	}
	double getPerimeter() {
		return Math.PI*(this.radius*2);
	}
	double getArea() {
		return Math.PI*this.radius*this.radius;
	}
	double getradius() {
		return this.radius;
	}
	int getoriginx() {
		return this.originX;
	}
	int getoriginy() {
		return this.originY;
	}
	void setradius(double r) {
		this.radius=r;
	}
	void setoringinx(int x) {
		this.originX=x;
	}
	void setoriginy(int y) {
		this.originY=y;
	}
	public String toString() {
		String ans;
		ans="Circle [color="+this.color+",radius="+this.radius+",originX="+this.originX+",originY="+this.originY+"]";
		return ans;
	}
}
class Triangle extends Shape{
	double sideA;
	double sideB;
	double sideC;
	Triangle(String c,double a,double b,double sc){
		super(c);
		this.sideA=a;
		this.sideB=b;
		this.sideC=sc;
		if(a+b<=sc||a+sc<=b||b+sc<=a)
			System.out.println("不是有效的边长");
	}
	double getPerimeter() {
		return this.sideA+this.sideB+this.sideC;
	}
	double getArea() {
		double p=this.getPerimeter()/2;
		double s;
		if(p*(p-this.sideA)*(p-this.sideB)*(p-this.sideC)<0)
			return 0;
		s=Math.sqrt(p*(p-this.sideA)*(p-this.sideB)*(p-this.sideC));
		return s;
	}
	public String toString() {
		return "Triangle[color="+this.color+",sideA="+this.sideA+",sideB="+this.sideB+",sideC="+this.sideC+"]";
	}
}
public class TestAbstactShape {
	public static void main(String[] args) {
		Shape t[]=new Shape[100];
		Random rm=new Random();
		int ran,x,y;
		double r,a,b,c,w,h,area=0.0,p=0.0;
		for(int i=0;i<100;i++) {
			ran=rm.nextInt(3);
			x=rm.nextInt(10);
			y=rm.nextInt(10);
			r=rm.nextInt(10);
			a=rm.nextInt(10);
			b=rm.nextInt(10);
			c=rm.nextInt(10);
			w=rm.nextInt(10);
			h=rm.nextInt(10);
			switch (ran) {
				case 0:
					Circle cir=new Circle("yellow",r,x,y);
					t[i]=cir;
					area+=t[i].getArea();
					p+=t[i].getPerimeter();
					System.out.println(t[i].toString());				
					break;
				case 1:
					t[i]=new Triangle("blue",a,b,c);
					area+=t[i].getArea();
					p+=t[i].getPerimeter();
					System.out.println(t[i].toString());
					break;
				case 2:
					t[i]=new Rectangle("green",w,h);
					area+=t[i].getArea();
					p+=t[i].getPerimeter();
					System.out.println(t[i].toString());
					break;
			}
		}
		System.out.println("总面积："+area);
		System.out.println("总周长："+p);
	}
}
