package stream1;
import java.io.*;
public class student {
	public static void main(String[] args) throws IOException {
		File f = new File("/Users/apple/Desktop/student.txt");
		FileReader in = new FileReader(f);
		FileWriter out = new FileWriter(new File("/Users/apple/Desktop/student2.txt"));
		int a, n = 0;
		String buf = "";
		String[] data = new String[100];
		while ((a = in.read()) != -1) {
			if ((char) a != '#')
				buf = buf + (char) a;
			else {
				data[n] = buf;
				n++;
				buf = "";
			}
		}

		int row, col, i = 0;
		String[][] str = new String[n / 5][5];
		for(row = 0; row < n / 5; row++)
		{
			for(col = 0; col < 5; col++)
			{
				str[row][col] = data[i++];
			}
		}
		for(i = 0; i < n / 5; i++)
		{
			System.out.print(str[i][0] + "总成绩为：");
			double sum = 0;
			for(col = 1; col < 5; col++)
				sum += Double.parseDouble(str[i][col]);
			String result = String.format("%.1f", sum);
			System.out.println(result);
			buf = str[i][0] + "#" + result + "#";
			out.write(buf);
		}
		in.close();
		out.close();
	}

}
