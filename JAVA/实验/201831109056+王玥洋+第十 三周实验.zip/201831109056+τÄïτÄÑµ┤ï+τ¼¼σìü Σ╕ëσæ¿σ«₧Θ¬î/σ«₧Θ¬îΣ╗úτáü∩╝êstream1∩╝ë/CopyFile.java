package stream1;

import java.io.*;

public class CopyFile {
    public static void main(String[] args) throws Exception { // 字节流拷贝
        FileInputStream in = new FileInputStream("/Users/apple/Desktop/1.txt");
        FileOutputStream out = new FileOutputStream("/Users/apple/Desktop/2.txt");
        
        byte[] buf = new byte[1024];
        int len;
        while ((len = in.read(buf)) != -1) {
            out.write(buf, 0, len);
        }
 
        in.close();
        out.close(); // 字符流拷贝
 
        BufferedReader bf = new BufferedReader(new FileReader("/Users/apple/Desktop/1.txt"));
        BufferedWriter bw = new BufferedWriter(new FileWriter("/Users/apple/Desktop/3.txt"));
        
        String str;
        while ((str = bf.readLine()) != null) {
            bw.write(str);
            bw.newLine();
        }
 
        bf.close();
        bw.close();
    }
}

