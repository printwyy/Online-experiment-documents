package setmap;

import java.util.Scanner;
import java.util.*;
public class map {
	public static void main(String[] args)
	{
		Scanner in = new Scanner(System.in);
		String s=in.nextLine();
		Map<String, String> a=new HashMap<>();
		a.put("1930","乌拉圭");
		a.put("1934","意大利");
		a.put("1938","意大利");
		a.put("1950","乌拉圭");
		a.put("1954","西德");
		a.put("1958","巴西");
		a.put("1962","巴西");
		a.put("1966","英格兰");
		a.put("1970","巴西");
		a.put("1974","西德");
		a.put("1978","阿根廷");
		a.put("1982","意大利");
		a.put("1986","阿根廷");
		a.put("1990","西德");
		a.put("1994","巴西");
		a.put("1998","法国");
		a.put("2002","巴西");
		a.put("2006","意大利");
		a.put("2010","西班牙");
		a.put("2014","德国");
		if(a.containsKey(s)) {
			System.out.println(a.get(s));
		}
		else {
			System.out.println("没有举办世界杯");
		}
	}
}
