package setmap;
import java.util.*;
class queue1{
	ArrayList a=new ArrayList();
	public void in(String s) {
		a.add(s);
	}
	public void deq() {
		a.remove(0);
	}
	public int len() {
		return a.size();
	}
}

public class queue {
	public static void main(String[] args)
	{
		queue1 s=new queue1();
		s.in("adsada");
		s.in("aaaabbb");
		s.in("treruty");
		System.out.println(s.a);
		System.out.println(s.len());
		s.deq();
		System.out.println(s.a);
	}
}
