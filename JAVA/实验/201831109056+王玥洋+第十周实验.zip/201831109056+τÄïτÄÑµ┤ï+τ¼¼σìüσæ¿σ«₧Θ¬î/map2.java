package setmap;

import java.util.*;
public class map2 {
	public static void main(String[] args)
	{
		Scanner in = new Scanner(System.in);
		String s=in.nextLine();
		Map<String, String> a=new HashMap<>();
		a.put("1930","乌拉圭");
		a.put("1934","意大利");
		a.put("1938","意大利");
		a.put("1950","乌拉圭");
		a.put("1954","西德");
		a.put("1958","巴西");
		a.put("1962","巴西");
		a.put("1966","英格兰");
		a.put("1970","巴西");
		a.put("1974","西德");
		a.put("1978","阿根廷");
		a.put("1982","意大利");
		a.put("1986","阿根廷");
		a.put("1990","西德");
		a.put("1994","巴西");
		a.put("1998","法国");
		a.put("2002","巴西");
		a.put("2006","意大利");
		a.put("2010","西班牙");
		a.put("2014","德国");
		if(a.containsValue(s)) {
			Iterator<Map.Entry<String, String>> it = a.entrySet().iterator();
	        while (it.hasNext()) {
	            Map.Entry<String, String> entry = it.next();
	            String k=entry.getKey();
	            String v=entry.getValue();
	            if(s.equals(v)) {
	            	System.out.printf("%s ",k);
	            }
	        }

		}
		
		else {
			System.out.println(s+"没有获得过世界杯");
		}
	}
}
