package stream1;

import java.io.RandomAccessFile; 
public class RandomFileTest {
	public static void main(String[] args) throws Exception{
		Employee e1 = new Employee("张强" , 23);//建立员工对象
		Employee e2 = new Employee("李飞" , 24);
		Employee e3 = new Employee("王敏" , 25);
		RandomAccessFile ra = new RandomAccessFile("\\Users\\apple\\Desktop\\employee.txt" , "rw");//以读写形式读取该txt文件 
		ra.write(e1.name.getBytes());//写入姓名
		ra.writeInt(e1.age); //写入年龄
		ra.write(e2.name.getBytes()); 
		ra.writeInt(e2.age); 
		ra.write(e3.name.getBytes());
		ra.writeInt(e3.age); 
		ra.close();
		RandomAccessFile raf = new RandomAccessFile("\\Users\\apple\\Desktop\\employee.txt" , "r"); //只以读形式打开txt文件
		int len = 10;//name存储长度为10
		raf.skipBytes(14);//name加上age的4个字节，跳14个字节到15开始读取
		System.out.println("第二个员工信息:");
		//String str = "";  不能用string来接受
		byte[] data=new byte[len];//用字节数组接收名称信息
		for (int i = 0 ; i < len ; i++){
			data[i]=raf.readByte();//一个字节一个字节接收
			}
		System.out.println("name:" + new String(data)); //将字节数组转换为string类型
		raf.skipBytes(4);//由于employee类型在name后加了一个二进制的0   需跳4个字节开始读取年龄
		System.out.println("age:" + raf.readInt()); //读取年龄
		System.out.println("第一个员工信息:"); 
		raf.seek(0);//指针跳到文件头 读取第一个员工信息
		byte[] data1=new byte[len];
		for (int i = 0 ; i < len ; i++){
			data1[i]=raf.readByte(); }
		System.out.println("name:" + new String(data1)); 
		raf.skipBytes(2);
		System.out.println("age:" + raf.readInt()); 
		System.out.println("第三个员工信息:"); 
		raf.skipBytes(14);
		byte[] data2=new byte[len];
		for (int i = 0 ; i < len ; i++){
			data2[i]=raf.readByte(); }
		System.out.println("name:" + new String(data2));
		raf.skipBytes(4);
		System.out.println("age:" + raf.readInt()); 
		raf.close();//关闭文件输入输出流
	} 
}
class Employee { 
	String name;
	int age;
	final static int LEN = 8;
	public Employee(String name , int age) {
		if(name.length() > LEN){
			name = name.substring(0 , 8);
		} 
		else {
			while (name.length() < LEN){
				name = name + "\u0000"; }
			this.name = name;
			this.age = age; }
	} 
}